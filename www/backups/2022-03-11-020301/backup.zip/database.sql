-- MariaDB dump 10.19  Distrib 10.6.4-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: forfans
-- ------------------------------------------------------
-- Server version	10.6.4-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `genders`
--

DROP TABLE IF EXISTS `genders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `genders` (
  `gender_id` int(11) NOT NULL AUTO_INCREMENT,
  `gender_langkey` varchar(60) NOT NULL,
  PRIMARY KEY (`gender_id`),
  UNIQUE KEY `gender_langkey` (`gender_langkey`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `genders`
--

LOCK TABLES `genders` WRITE;
/*!40000 ALTER TABLE `genders` DISABLE KEYS */;
INSERT INTO `genders` VALUES (3,'female'),(10,'fluid'),(11,'fluid_cis_f'),(12,'fluid_cis_m'),(2,'male'),(1,'na'),(5,'transexual'),(4,'transgender'),(8,'transgender_ftm'),(6,'transgender_mtf'),(9,'transsexual_ftm'),(7,'transsexual_mtf');
/*!40000 ALTER TABLE `genders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invitation_codes`
--

DROP TABLE IF EXISTS `invitation_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invitation_codes` (
  `invitation_id` int(11) NOT NULL AUTO_INCREMENT,
  `invitation_code` varchar(50) NOT NULL,
  `uses_left` int(11) NOT NULL DEFAULT 1,
  `invitation_creator` int(11) NOT NULL,
  `invitation_time` datetime NOT NULL,
  PRIMARY KEY (`invitation_id`),
  KEY `invitation_creator` (`invitation_creator`),
  CONSTRAINT `invitation_codes_ibfk_1` FOREIGN KEY (`invitation_creator`) REFERENCES `usuarios` (`id_usuarios`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invitation_codes`
--

LOCK TABLES `invitation_codes` WRITE;
/*!40000 ALTER TABLE `invitation_codes` DISABLE KEYS */;
INSERT INTO `invitation_codes` VALUES (1,'DevOps_TEAM_4891516535hgb',48,1,'2022-02-28 22:35:25');
/*!40000 ALTER TABLE `invitation_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mensajes`
--

DROP TABLE IF EXISTS `mensajes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mensajes` (
  `id_mensaje` int(11) NOT NULL,
  `id_emisor` int(11) NOT NULL,
  `id_receptor` int(11) NOT NULL,
  `contenido` text NOT NULL,
  `contenido_media` varchar(2048) NOT NULL,
  `fecha_hora` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_mensaje`),
  KEY `id_emisor` (`id_emisor`,`id_receptor`),
  KEY `id_receptor` (`id_receptor`),
  CONSTRAINT `mensajes_ibfk_1` FOREIGN KEY (`id_emisor`) REFERENCES `usuarios` (`id_usuarios`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `mensajes_ibfk_2` FOREIGN KEY (`id_receptor`) REFERENCES `usuarios` (`id_usuarios`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mensajes`
--

LOCK TABLES `mensajes` WRITE;
/*!40000 ALTER TABLE `mensajes` DISABLE KEYS */;
/*!40000 ALTER TABLE `mensajes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `for_id` int(11) DEFAULT NULL,
  `post_text` varchar(2400) DEFAULT NULL,
  `is_nsfw` tinyint(1) NOT NULL DEFAULT 0,
  `post_img_array` varchar(2400) DEFAULT NULL,
  `post_video_array` varchar(2400) DEFAULT NULL,
  `post_file_array` varchar(2400) DEFAULT NULL,
  `post_audio_array` varchar(2400) DEFAULT NULL,
  `post_gif_array` varchar(1024) DEFAULT NULL,
  `for_fans` tinyint(1) NOT NULL DEFAULT 0,
  `for_everyone` tinyint(1) NOT NULL DEFAULT 1,
  `post_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `post_donations` decimal(10,2) NOT NULL DEFAULT 0.00,
  `post_removed` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`post_id`),
  KEY `user_id` (`user_id`,`for_id`),
  KEY `for_id` (`for_id`),
  CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `usuarios` (`id_usuarios`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `posts_ibfk_2` FOREIGN KEY (`for_id`) REFERENCES `usuarios` (`id_usuarios`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES (1,1,NULL,'Esta es la primera publicacion!',0,NULL,NULL,NULL,NULL,NULL,0,0,'2022-02-22 15:49:39',0.00,0),(2,1,NULL,'',0,'[\"{fullsiteurl}upload\\/pictures\\/ccd2a359a64bb4d2dcf1c7ba8611519e.webp\"]',NULL,NULL,NULL,NULL,0,0,'2022-02-26 01:54:23',0.00,0),(3,1,NULL,'www',0,NULL,NULL,NULL,NULL,NULL,0,0,'2022-03-01 15:46:59',0.00,0),(4,1,NULL,'',0,'[\"{fullsiteurl}upload\\/pictures\\/9928d9973b0877198bc1d0f418c7f3cb.webp\",\"{fullsiteurl}upload\\/pictures\\/e4f38a5897df25614da99739712f272e.webp\",\"{fullsiteurl}upload\\/pictures\\/c87b1914e94b381a547fc1d4b165ef65.webp\"]',NULL,NULL,NULL,NULL,0,0,'2022-03-01 22:31:24',0.00,0),(8,1,NULL,'Mia khalifa al ver mi pito jijijija',1,'[\"{fullsiteurl}upload\\/pictures\\/b984b3f94a9e4171eed8bdfed433d9fc.webp\"]',NULL,NULL,NULL,NULL,0,1,'2022-03-01 22:32:12',0.00,0),(26,1,NULL,'Bienvenido a forfans!',0,NULL,NULL,NULL,NULL,NULL,0,1,'2022-03-04 16:38:02',0.00,0);
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relationships`
--

DROP TABLE IF EXISTS `relationships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relationships` (
  `rel_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_related` int(11) NOT NULL,
  `relation type` varchar(200) NOT NULL,
  `related_to` int(11) NOT NULL,
  PRIMARY KEY (`rel_id`),
  KEY `user_related` (`user_related`,`related_to`),
  KEY `related_to` (`related_to`),
  CONSTRAINT `relationships_ibfk_1` FOREIGN KEY (`user_related`) REFERENCES `usuarios` (`id_usuarios`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `relationships_ibfk_2` FOREIGN KEY (`related_to`) REFERENCES `usuarios` (`id_usuarios`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relationships`
--

LOCK TABLES `relationships` WRITE;
/*!40000 ALTER TABLE `relationships` DISABLE KEYS */;
INSERT INTO `relationships` VALUES (1,2,'follow',1),(2,3,'follow',1),(3,1,'follow',3);
/*!40000 ALTER TABLE `relationships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sexual_orientations`
--

DROP TABLE IF EXISTS `sexual_orientations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sexual_orientations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `langkey` varchar(20) NOT NULL,
  `css-cone-flag` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sexual_orientations`
--

LOCK TABLES `sexual_orientations` WRITE;
/*!40000 ALTER TABLE `sexual_orientations` DISABLE KEYS */;
INSERT INTO `sexual_orientations` VALUES (1,'heterosexual','conic-gradient(black, white, black, white, black, white, black);'),(2,'homosexual','conic-gradient(red, orange, yellow, lime, blue, red);'),(3,'bisexual','conic-gradient(pink, purple, blue, pink);'),(4,'pansexual','conic-gradient(pink, yellow, cyan, pink);'),(6,'demisexual','conic-gradient(white, white, purple, white, white, black, white);'),(7,'lithsexual','conic-gradient(FireBrick, coral, gold, white, DarkGray, DimGray, FireBrick);'),(8,'autosexual','conic-gradient(DimGrey, DarkTurquoise, DimGrey;'),(9,'antrosexual','conic-gradient(Turquoise, White, Purple, Turquoise);');
/*!40000 ALTER TABLE `sexual_orientations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tokens` (
  `token_id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_issued` varchar(100) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `token` varchar(520) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`token_id`),
  KEY `Usuario` (`user_id`),
  CONSTRAINT `tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `usuarios` (`id_usuarios`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=186 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
INSERT INTO `tokens` VALUES (1,'localhost','2021-11-10 15:41:31','TOKEN_MANUAL',1),(74,'37.133.114.182','2021-12-14 16:11:27','afa68251edfc6d273d48a4adb7c6db1c5d05c7c144b0123cb40b0991953b1ece95d043e5dcaf773ce836578fe7f6d603e35e60c213850b1d1a93a4f',1),(75,'37.133.114.182','2021-12-20 16:10:41','f22b333e553a1651ba046fff17af4c1ce5a924ba1581593fde0f768cb6de1256554c0acb729adf50d47dbcadff2e663078969f6e576a5bbe83e03730',1),(76,'37.133.114.182','2021-12-27 09:46:46','cbd2f1314749d70f676e41c23e738f1c5b9f32d942da74419576d96343d50775fa94d1aa560912cc6248f3088bb5dfba1cd14abe5d3c17b195931d90',1),(78,'90.167.86.229','2022-01-11 15:09:45','25bd7ebb5a2aa71e4a5430e378613914e50058c8e9c9c877313d5345371f9bb7eafe14955cacf16d870620f9eda6d922bf4b00346009b51b3f8af1c6',1),(79,'90.167.86.229','2022-01-11 15:25:37','6a43f1e7717f7a93a8676e239858586c33612835b4f33c77726df564d04391343658842fd51b6737fc9d5d15d86b92c08635df9fbf97b0fc17e41e16',1),(80,'37.133.114.182','2022-01-17 16:25:39','dd96229d7c9287a4aaefe45f785fd3fdd9768daf5a5f7de69c03cf42dfd6fdbccabfe3f28be851b1f9ade5ae3afd3f911b741bdda410c3324fa14431',1),(81,'90.167.87.47','2022-01-18 14:51:55','93cbf08ba741c389139ae81bed74259779c4c500842cd78e537bf3ca818a6b7d772b24ab74a13c99477594c5a98af9e94544806275e2b72dd54b6b36',1),(84,'185.124.31.156','2022-01-20 17:11:20','4752963e275bd093a9b9b27f46eb5a16eb92832851078a01d72da88324e55ac6380a0f3addf5a80d0215497bd1d70512fc5f56c8f6a9d281f4d4ecd2',1),(86,'37.133.114.182','2022-01-20 17:16:59','fed619c4e42ba285478b47ce84947f6e95728e1955f40008727c74ac5fd08a12569aec81bbea2a23dd493c87b0f37741242e9ebbb8f8f454526a3697',1),(98,'2.136.29.100','2022-01-27 15:46:05','04bb0eedfcc9815b9317038e6f6c6ec6b60977b364f6af081b9fc50df8bb21ac940e7c5c795e60fa92bb47b44fb0488d3850fbc436742ba20b73f7dd',1),(99,'37.133.114.182','2022-01-27 17:16:00','fc5f9f28b6a32567e4d8b2da7e341972b8b49e5b8259a77da3ecc35621179cb797963d363a9df28cf99d47cfa9c4bdd6890ebc45a570993db1d3717c',1),(100,'2.136.29.100','2022-01-27 17:44:14','165f7e1a8d431d97abf34e10a83dcf9b1d0d944ae93138228b94ddb672f04aa7c6570a4a5a676358fe48466e9bc14c7780f458994ef51bbb875023f0',1),(101,'37.133.114.182','2022-01-28 15:07:38','ff830018beff39db656fecc1c728dfc731531af3228a9087343abcce5444adf29fb4bcccd3b216862cdec1fb3675161510f4d15d6bbf90c3e2655ddc',1),(103,'37.133.114.182','2022-01-31 10:53:02','5e34c2a8c812e95762214d9621bbf34944871f983a08501ead9c2400c5bd2532158a3ee8631f4826f7fdb3126817372b731790efec0d2648ebdd37b6',1),(109,'37.133.114.182','2022-02-03 17:55:12','b3877c8feff1272ce8ddf3aeca4ff8577c2e782486f55243b4b1a48709433b929a4fdb4c2e7d772fc6a0d8699d108851ad970abeb75fa3f2a5bcfedd',1),(110,'37.133.114.182','2022-02-04 15:51:55','6b556be2d19d8e137aba8658363ca9fff9618d4351e192d80aa284b5762bc96b6dbf424ef9526a9d07f696ba0040d229d4356f5e3ac5f10f68a90a6e',1),(113,'139.47.37.13','2022-02-09 12:13:03','5aa67c94a2019bef1dd100d07dc4c2cfff6a740b7c735b5e67bec66b6719b29d1752cc4cc1e4a87e52bc31b814f1da13a32cadf4a5dccb2db2b53bb8',1),(114,'37.133.114.182','2022-02-09 14:59:12','d55a00ab16908a2d8e2397fe5fb40ba8e5a2b93dc0fd656f250c8225f97c7e91baa1490a3b36376ba05d982d48c5ecb9eca6c4e6dadd92ebf75fb3b3',1),(115,'37.133.114.182','2022-02-09 14:59:12','cf61420e35af8f62d715b92d1b40c603a49e49cfb881035635fde746b3a7e4a37dd4f48bb294ecbac93464da2e95298d9c161fbb6cf5dc1523ae55f2',1),(116,'37.133.114.182','2022-02-09 14:59:12','11c6430d13031cd8b95433149ae92fa242d54277d475d0464b430deee57c6376dc50420f6aacb2405e177267936c6f244df7b3240e39adea8aa96bcb',1),(117,'37.133.114.182','2022-02-09 14:59:12','1e9009094353b51f3906d670df09af7dc86058c48dddd42af6ab1114cb817dfd6543ca4c01fc132de036e35d84ad9b350ff6e0028c8f52077e69426b',1),(118,'37.133.114.182','2022-02-09 19:17:19','e1f1c27661f5662d0310d5569384c391a3d1b5f163e95672814311c840b1c682459bf59b48b78ce498cc8a0714acf8dd85ff2f19edcf7b434456ce26',1),(119,'37.133.114.182','2022-02-09 19:17:20','05a06666d22e1875b9f4b362d8b767f93cafef1a830c34a73bcb9a2526323df02f9fce0c95e371dcf2c86b14826270f67457773f1dcea9a33ba18a51',1),(120,'37.133.114.182','2022-02-11 17:27:42','96796deffb2cfa19ba28fbcc5683b7be74f48cc4378219ab003e48682d2f4cea039b22a58f0364ce006783a5267e8484662a956857f2aa91f3320002',1),(122,'37.133.114.182','2022-02-14 14:19:12','bf0df5cea686f29ce3669e4f321eacc85e2c5ac522e6e21b086535bbfd08aba5906bdb747102cd262cf37e8e9aa05fe4c479ea68c5ffb6d0d8e459be',1),(123,'90.167.87.223','2022-02-14 16:30:18','75f890fffd414d84894c71f2ddd8cc9c5262a5bd36c972a21c540e8216311f29f9941bc989ca06a4c6d462c3744c61f54a889aa2f692f056038968e8',1),(125,'90.167.87.41','2022-02-15 17:45:39','54030a6b5b47ea0d2d8c1c160db34aaff809905c1296f1282929b8622c3052f7df995d6137aa27a5ff479981ecdffab2ae40fb15a1acbf5393987680',1),(127,'37.133.114.182','2022-02-16 17:30:12','4a3d303b827227573d8a0c30369101748d0504f31371c99bee04a209b4d1ef0136ea865500fe5e5a72e57c97f21d1d544d779abc529bf6e2db93a650',1),(128,'2.136.29.100','2022-02-16 18:53:35','c53f05fc55b1d6f31012646231972bdf8f5db558c838cd88982a856ef3ab299e9d77a59d5c20966aa546410a9158654f695b462308e6f5176e65121d',1),(129,'90.167.86.255','2022-02-17 10:55:39','f74e0e7c3b23417367eacb146d067f93723782790a437264e88ebd992617420c9685cedc26ca45e093f6bc595b7d7cead4cfad7434e6595cea9cdc7a',1),(130,'84.78.248.19','2022-02-18 18:25:44','3f6f22fb05f3c3bbe49a7260c016029429c7fd20c88efe4d581145d8022e67f961f285cffcb9f85288219949399e69ecc21432132a94881e35593b2a',1),(131,'37.133.114.182','2022-02-20 17:16:31','84125c664fef9b41694c6b24024fcec95206e81840d87f51c5194d05fcabae483f1e4b813844ab021ff55aa9ef908316dd3c1519d6e4368043052e7b',1),(135,'217.127.77.86','2022-02-22 15:10:02','0ebb5b2812e2d9ce5788816599afd7e25791b764c63d2c9d91a0e0c186aaf2ad73f64cd48c7a1ed8efda979e2b1f70854853eb10ab026ec65ec5d51b',2),(136,'37.133.114.182','2022-02-24 14:40:49','93f81b35be771273540fe82e101fc830fa32eab5629f9b3e8b9ba3b277e30c5bd42a398914f69430b30a1b317d97e879bb808494fb99c1fa90097479',1),(137,'90.167.86.189','2022-02-24 17:45:07','bfa154ea73e8a7fb1996a03e88db543704e05249a61f0158603e1ecaa050dbae251db81ecf844ff4ef63e001783bbdd49928c28f112be6dff37f2085',1),(138,'90.167.86.189','2022-02-26 01:53:10','785d4e45197f732390319e0e321683ce2b68e2784da02b06ff8da1cac6f439294fc4361f2386573a64ef7ba308afbd2b9ec3d3ed9c3e91a2302891f0',1),(139,'90.167.86.189','2022-02-26 01:53:45','79e46540aa817258020e1589913d2a095a2aa3b642e98eccaa1fc7836ca24b96af526da5d5d2d4c6145440a2a9183be3b26ab96ad3c28aa8aebc6d59',1),(140,'37.133.114.182','2022-02-27 15:25:58','7d55b494a5fb7423e82624c074a2aa6371588763df37e32efd2b09fa3a25d260ab4f44a83131e50c29626ddcdbb560549302172c2574d419b8a7f279',1),(142,'37.133.114.182','2022-02-28 23:39:53','e5aedda90dc4b5f33241fc4c784bfc8065c956e2ebab8d670c1bf8178717f64c8f5bb13ac5dda39b2fe664aa78b114418ac73e028ee6505f04bd964c',1),(143,'37.133.114.182','2022-03-01 15:44:10','59b48de7fe8caa46e1ce8bffabf160c4e1e698496f8440ca9021afade87c2c53b779ffb5e849e61d2685e80ced3b9cc6ceaae2d54a631c4087d77008',1),(145,'83.50.55.24','2022-03-01 16:05:00','71219e1002d307e60cf51d8eaf5ab9afbd5bd6bece25d0f12056a834debd434e5f59922f0a00ab43fcad96a6f1879e3c3ea3f5e253b20668e1a38a4b',1),(146,'90.167.87.130','2022-03-01 18:27:08','9cb80044c9d898982ab28dfe632791a0efc586dc88e4286668f4c0ef5c057fbda2d508122860f764d0d4038c0ca78ed01f90bc5528b6ba24faedb99a',1),(147,'37.133.114.182','2022-03-01 22:01:35','f4ca43090563a85f99292751f733a1ab0d199c28637772144d712e883fd9c286a88ea67ddbc1c15bb08b5aaa3ad87be3e6658e5286d997916f21e8af',1),(148,'37.133.114.182','2022-03-01 23:07:46','ab33853f0b2a73946ac707717e06fcd12a3d626c15e71ffa4fc6210f1b1389b9141a58973583c0d48970317d0d4f7897fe981738fd967c4ce8323860',1),(149,'37.133.114.182','2022-03-01 23:27:38','2fcf80679a31e9d66f640d93a8a8de9b188daff39dfcb74270c556b59bd7d9c4b47527bb23f070bc49170d1b5552277678ff0376411e4962cf3cd53d',1),(150,'37.133.114.182','2022-03-01 23:28:14','7d575c3b154808e603fc1cb567e99cc3d8380f2edbc074ad8a94c3bbde45e4acb4cc15cd16a4446d18d65a43c20ee6925a21206b6164c0f9e0fe379f',1),(151,'37.133.114.182','2022-03-01 23:43:05','d5f488013b3de4c78b75f9b8ba8dd6a28f3079fd3484e716d5dfe17ff656307b2e255cfe8b81d4433d39d1768da727c8b04114473a39835fef09b887',1),(152,'37.133.114.182','2022-03-02 17:17:09','3cc6d404f7d21ee19bb8bf644c3169e159287f531c01ab8437f5649c171da4910a2f1354d540c5b400e9bda7981406485790e1a02469e1e07a6773a8',1),(155,'217.127.77.86','2022-03-03 17:16:22','563adfb055f9bcb1eba39b9112ee86061ddf4653e3ebaf3ba7998255066f6e6e2247060b79d11416b3d59b334dd95deffb6db4f394a10a3bbd7682a1',1),(156,'83.50.55.24','2022-03-04 15:22:18','7bc790aecddbe2edfeaa9fc83fa0aed3a17c831d4c7d193d6c99349b58dfe771074bee30e90e101b2339edcdb50d52a50954f66c6a731d5cd6007f79',1),(158,'37.133.114.182','2022-03-08 10:29:29','0a510ad3941ee1be2bd437dabf1e2471d592615313586b417917f5860950639b4e4f1c67b32b86448b66a10cc925e2ee8a39f05e1f4a5b69de7660ce',1),(160,'83.50.164.77','2022-03-08 15:03:49','88572f63805d2ea7a29a656647cb79bdeaa2f2f33e4ef7a6300d21e53522db36405067c9c6afe2124db0f26c85cfdb9b07b23d0c926258a27106c5ff',2),(162,'217.127.77.86','2022-03-08 15:07:49','515926a0fb3c91ac946c30aff62be64dce6106c1ff5f003207a04e9c4a631a597428ca661e54d429b9aea5be0adaa741ddd05e7afd03f9c2b8147e82',2),(164,'217.127.77.86','2022-03-08 15:42:44','46efa25fdf88756ef178d66869de47e719db489d4cc67016ce5d21676cc71c2a97fbbc34ba3dc9d7266552b9850b208aa3e0bff8b73311ec6a602d37',1),(165,'83.50.164.77','2022-03-09 16:54:43','40a82f8e6163be3d412c4001854f860d9e859e65adba6b5d77bb554327cc3f4976de807c036cea4dbaeecd84800dee12c272f94d0ac49be96cf2443f',1),(168,'217.127.77.86','2022-03-10 15:18:17','3de10e02bf7f1fafd2d64c9dc88f11324157dd7ec80c923f1cc551804ebe888bd2a3cede16c2327822167ef9c00f8bcbfc302d62538f37ac5ce7ec48',1),(169,'37.133.114.182','2022-03-10 17:09:13','28d0d52557799e079d46de11017093084abccfa4ddbda5ef4e889f610e8ea07a0fd2a6d413fa2be0c60cfd97f946ee75289c464a774125395928051f',1),(171,'37.133.114.182','2022-03-10 17:49:16','e81367b53b34cf0ff4f66cda458378aa9f00e510623cc4b41f0d040d5cc21db9d77eeeb14fbedf125321300fe4d3223c6f001c630ef92d82dfbc3f77',1),(173,'37.133.114.182','2022-03-10 17:52:20','cccaaaffe8b7a8561ff3c3a1c0ed20942b567c9c46488595f8bb8b466c8f8e483876415a9ed5c8edf25ec60c00838b1d528f248230b630e605dd1c57',1),(178,'37.133.114.182','2022-03-10 18:02:17','0eed283e3b09a986a330d763408a4418e6a691f0004ed6771df71efc469f492f5d0ad821ebf889074a0012def0f21da2bb523bc1c90af7f2b4b96728',1),(179,'37.133.114.182','2022-03-10 18:08:50','2f08cc482bd27ab287c9bcf9de1379ba6ad78ef0d4868fec82c6f45b947123fadf707a4f1d6d186759ef587001971a1acb0025d2866abeabe29a5af6',1),(180,'37.133.114.182','2022-03-10 18:15:22','da0345c5a0791ad76d981159dd3c2dd8c2610e8a68f395cabb43aba987efdba186cd532b706ed24ad78ad298c376cd1a4ca5b8c59621c4685c5c4fdb',1),(181,'37.133.114.182','2022-03-10 18:17:35','71f69cae2aaf415f11554e2a2b7c177bf39bb87c2e8e7f7e37b89c08b54cdf8a68769ffd4a2b89996ff49588afc09a564abedd2942b60fca0a8213a2',1),(185,'37.133.114.182','2022-03-11 02:55:16','a3a6cf851d591ed5698c67b5119851d4ebfe78254134093b5f87f50ceefe322db7a2bb542078ff6bd08a5c2f685bcec66545b6583ec97951b5874f97',1);
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `id_usuarios` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) NOT NULL,
  `correo` varchar(250) NOT NULL,
  `profile_picture_rpath` varchar(255) NOT NULL DEFAULT 'themes/default/assets/img/default_pfp.webp',
  `cover_picture_rpath` varchar(1024) NOT NULL DEFAULT 'themes/default/assets/img/default-cover.webp',
  `contraseña` varchar(70) NOT NULL,
  `gender_id` int(11) NOT NULL DEFAULT 1,
  `sexual_orientations_id` int(11) NOT NULL DEFAULT 1,
  `fecha_de_inicio` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fecha_de_la_ultima_conexion` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `nombre` varchar(30) NOT NULL,
  `apellidos` varchar(200) NOT NULL,
  `displayName` varchar(18) NOT NULL,
  `bio` text NOT NULL,
  `balance` decimal(11,2) NOT NULL DEFAULT 0.00,
  `points` int(11) NOT NULL DEFAULT 0,
  `aviable_invites` int(11) NOT NULL DEFAULT 0,
  `cumple` date DEFAULT NULL,
  `invite_used` int(11) DEFAULT NULL,
  `default_theme_variable` varchar(28) DEFAULT NULL,
  `lang` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`id_usuarios`),
  UNIQUE KEY `username` (`username`),
  KEY `sexual_orientations_id` (`sexual_orientations_id`),
  KEY `gender_id` (`gender_id`),
  KEY `invite_used` (`invite_used`),
  CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`sexual_orientations_id`) REFERENCES `sexual_orientations` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `usuarios_ibfk_2` FOREIGN KEY (`gender_id`) REFERENCES `genders` (`gender_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `usuarios_ibfk_3` FOREIGN KEY (`invite_used`) REFERENCES `invitation_codes` (`invitation_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'admin','admin@societyplus.net','upload/pictures/admin_pfp.jpg','themes/default/assets/img/default-cover.webp','$2y$10$9hZoJU0EYwE6YDulK4oPTOjXsT9HyPTaCjWhx7JILkOqIFeCXp2QO',2,3,'2022-03-10 18:20:21','0000-00-00 00:00:00','LiLPandemio','Moreno','LiLPandemio','El admin, el unico, el real, el inigualable',160000.00,99999,99,'2003-03-24',NULL,'journal','es'),(2,'brmepa20','brmepa20@bemen3.cat','themes/default/assets/img/default_pfp.webp','themes/default/assets/img/default-cover.webp','$2y$10$9hZoJU0EYwE6YDulK4oPTOjXsT9HyPTaCjWhx7JILkOqIFeCXp2QO',2,1,'2022-03-10 15:42:48','0000-00-00 00:00:00','Bryan','medrano pacheco','Bryan','I\'m a new user!',0.00,0,0,'2003-06-09',1,'cyborg',NULL),(3,'issx_nce','isabelchavarrias10@gmail.com','themes/default/assets/img/default_pfp.webp','themes/default/assets/img/default-cover.webp','$2y$10$9hZoJU0EYwE6YDulK4oPTOjXsT9HyPTaCjWhx7JILkOqIFeCXp2QO',3,3,'2022-03-10 15:47:31','0000-00-00 00:00:00','Isabel','Chavarrias Mitrovic','Issx','La mano del admin, no tocar :)',0.00,0,0,'2002-09-10',1,NULL,NULL);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-11 14:56:01
